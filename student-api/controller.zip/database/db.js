const sql = require('mssql/msnodesqlv8')

const config = {
  database: 'db_a88529_pifdb',
  server: 'SQL8006.site4now.net',
  driver: 'msnodesqlv8',
  user: 'db_a88529_pifdb_admin',
  password: 'PifAssignment2023',
  options: {
    trustedConnection: false
  }
} 
const poolPromise = new sql.ConnectionPool(config)
  .connect()
  .then(pool => { 
    console.log('Connected to MSSQL')
    return pool
  })
  .catch(err => console.log('Database Connection Failed! Bad Config: ', err))

module.exports = {
  sql, poolPromise
}